<?php
    get_footer();

?>



<!-- Force hide inherit WP footer -->
<style>
    #footer{
        display: none!important;
    }
</style>

<script>
    document.getElementsByTagName('hr')[0].style.display = 'none';
</script>